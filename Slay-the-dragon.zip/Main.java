import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

class Main {	
 
  
public static void main(String[] args){
    new running();
  }

}

